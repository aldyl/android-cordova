

// funciones de pertenencia genericas

function trapezoidal(u, a, b, c, d){
	if(u<a || u>d)
		return 0;
	else if(b<=u && u<=c)
		return 1;
	else if(a<=u && u<b)
		return (u-a)/(b-a);
	else
		return (d-u)/(d-c);
}

function triangular(u, a, b, c){
	if(u<a || u>c)
		return 0;
	else if(a<=u && u<=b)
		return (u-a)/(b-a);
	else 
		return (c-u)/(c-b);
}

function singleton(u, a){
	if(u==a)
		return 1;
	else
		return 0;
}

function decS(u, a, b){
	if(u>b)
		return 0;
	if(u<=a)
		return 1;
	else
		return (b-u)/(b-a);
}

function crecS(u, a, b){
	if(u>=b)
		return 1;
	if(u<a)
		return 0;
	else
		return (u-a)/(b-a);
}








// funciones de pertenencia

// fiebre

function fiebreBaja(u){ // FB
	return decS(u,37.5,39);
}

function fiebreAlta(u){  // FA
	return crecS(u,37.5,39)
}

// dolor articulaciones

function dolorArticAlto(u){ // DAA
	return crecS(u,1,3);
}

function dolorArticBajo(u){ // DBA
	return decS(u,1,3);
}

// enrojecimiento de ojos

function enrojecAlto(u){ // EAO
	return crecS(u,1,4);
}


function enrojecBajo(u){ // EBO
	return decS(u,1,4);
}

// dolor muscular

function dolorAlto(u){ // DAM
	return crecS(u,1,4);
}


function dolorBajo(u){ // DBM
	return decS(u,1,4);
}


// cantidad de dias que estuvo en zona peligrosa

function haceMuchosDias(u){ // MD
	return crecS(u,10,15);
}

function hacePocosDias(u){ // PD
	return decS(u,0,5);
}

function rangoMedioDias(u){ // RMD
	return trapezoidal(u,0,5,10,15);
}

// resultado

mCenter = 25;
mmCenter = 50;
bCenter = 75;

function bien(u){ // B
	return decS(u,0,50);
}

function masMenos(u){ // MM
	return trapezoidal(u,0,25,75,100);
}

function mal(u){ // M
	return crecS(u,50,100);
}




var FA,FB, 
	DAA,DBA, 
	EAO,EBO,
	DAM,DBM,
	MD,RMD,PD,
	// resultado
	M,MM,B;

function fuzzify(fiebre,
					dolorArtic,
					enrojecOjos,
					dolorMusc,
					cantDias){
					
	FA = fiebreAlta(fiebre);
	FB = fiebreBaja(fiebre);
	
	DAA = dolorArticAlto(dolorArtic);
	DBA = dolorArticBajo(dolorArtic);
	
	EAO = enrojecAlto(enrojecOjos);
	EBO = enrojecBajo(enrojecOjos);
	
	DAM = dolorAlto(dolorMusc);
	DBM = dolorBajo(dolorMusc);
	
	MD = haceMuchosDias(cantDias);
	RMD = rangoMedioDias(cantDias);
	PD = hacePocosDias(cantDias);
}



fuzzyRules = [[]];

function fls(){
	res = 0;
	for(i=0; i<fuzzyRules.length; i++){
		inic = 0;
		if(fuzzyRules[i][0]=='not')
			inic = 0;
		else	
			inic = 1;
		
		
		for(e=inic; e<fuzzyRules[i].length; e++){
			if(fuzzyRules[i][e] == 'or')
				res = (fuzzyRules[i][e-1]<fuzzyRules[i][e+1])?fuzzyRules[i][e+1]:fuzzyRules[i][e-1];
			else if(fuzzyRules[i][e] == 'and')
				res = (fuzzyRules[i][e-1]>fuzzyRules[i][e+1])?fuzzyRules[i][e+1]:fuzzyRules[i][e-1];
			else if(fuzzyRules[i][e] == 'not')
				res = 1 - fuzzyRules[i][e+1];
		}
		fuzzyRules[i][2] = res;
		res = 0;
	}		
}


function desfuzzify(){
	m = 0;
	mm = 0;
	b = 0;
	
	for(e=1; e<fuzzyRules[i].length; e++){
		switch(fuzzyRules[i][1]){
		case 'M':
			m += fuzzyRules[i][2]*fuzzyRules[i][2];
		break;
		case 'MM':
			mm += fuzzyRules[i][2]*fuzzyRules[i][2];
		break;
		case 'B':
			b += fuzzyRules[i][2]*fuzzyRules[i][2];
		break;
		}
	}
	
	Math.sqrt(m);
	Math.sqrt(mm);
	Math.sqrt(b);
	
	return mCenter*m + mmCenter*mm + bCenter*b;
}


function diagnostic(fiebre,
					dolorArtic,
					enrojecOjos,
					dolorMusc,
					cantDias){
	
	fuzzify(fiebre,dolorArtic,enrojecOjos,dolorMusc,cantDias);
	fls();
	r = desfuzzify();
	
	document.getElementById("prob").text = "Probabilidad contagio "+ r +" %";
}


java -jar Uninstaller/uninstaller.jar

Jitsi is currently under active development.
The version you are running is only experimental and may not
work as expected. Please refer to
<a href="https://jitsi.org/">https://jitsi.org/</a>
for more information.

Packages needed: git, rpm-build, java-devel, ant

1) Create folder ~/rpmbuild
2) Copy build-jitsi-rpm.sh there
3) Call build-jitsi-rpm.sh script, like:
   ~/rpmbuild/build-jitsi-rpm.sh VERSION GOOGLE_API_ID GOOGLE_API_SECRET
